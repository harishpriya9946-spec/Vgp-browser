package com.vgp.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView web;
    EditText bar;
    ProgressBar pb;
    SharedPreferences sp;
    String lastUrl = "";

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        sp = getSharedPreferences("vgp", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT <= 28)
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        else if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        bar = new EditText(this);
        bar.setSingleLine();
        bar.setHint("Search or type address");
        bar.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        bar.setOnEditorActionListener((v, a, e) -> { go(bar.getText().toString()); return true; });
        top.addView(bar, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(btn("Go", v -> go(bar.getText().toString())));

        pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);

        web = new WebView(this);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setBuiltInZoomControls(true);
        st.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { bar.setText(u); }
            @Override public void onPageFinished(WebView v, String u) {
                if (!u.equals(lastUrl)) { lastUrl = u; add("hist", v.getTitle(), u); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                pb.setProgress(p);
                pb.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> download(url, ua, cd, mime));

        LinearLayout bottom = new LinearLayout(this);
        String[] labels = {"◀", "▶", "★", "📑", "🕘", "⬇"};
        View.OnClickListener[] acts = {
            v -> { if (web.canGoBack()) web.goBack(); },
            v -> { if (web.canGoForward()) web.goForward(); },
            v -> { add("watch", web.getTitle(), web.getUrl()); Toast.makeText(this, "Added to watchlist", Toast.LENGTH_SHORT).show(); },
            v -> showList("watch", "Watchlist"),
            v -> showList("hist", "History"),
            v -> showDownloads()
        };
        for (int i = 0; i < labels.length; i++)
            bottom.addView(btn(labels[i], acts[i]), new LinearLayout.LayoutParams(0, -2, 1));

        root.addView(top);
        root.addView(pb, new LinearLayout.LayoutParams(-1, dp(3)));
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(bottom);
        setContentView(root);
        go("https://www.google.com");
    }

    void go(String s) {
        s = s.trim();
        if (s.isEmpty()) return;
        String u;
        if (s.matches("^https?://.*")) u = s;
        else if (!s.contains(" ") && s.contains(".")) u = "https://" + s;
        else u = "https://www.google.com/search?q=" + Uri.encode(s);
        web.loadUrl(u);
    }

    void add(String key, String t, String u) {
        if (u == null) return;
        try {
            JSONArray a = new JSONArray(sp.getString(key, "[]"));
            JSONArray n = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", (t == null || t.isEmpty()) ? u : t);
            o.put("u", u);
            n.put(o);
            for (int i = 0; i < a.length() && i < 199; i++)
                if (!a.getJSONObject(i).getString("u").equals(u)) n.put(a.get(i));
            sp.edit().putString(key, n.toString()).apply();
        } catch (Exception e) { }
    }

    void showList(String key, String title) {
        try {
            final JSONArray a = new JSONArray(sp.getString(key, "[]"));
            String[] names = new String[a.length()];
            for (int i = 0; i < names.length; i++)
                names[i] = a.getJSONObject(i).getString("t") + "\n" + a.getJSONObject(i).getString("u");
            AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle(title);
            if (names.length == 0) d.setMessage("Nothing here yet.");
            else d.setItems(names, (x, i) -> { try { go(a.getJSONObject(i).getString("u")); } catch (Exception e) { } });
            d.setNeutralButton("Clear", (x, i) -> sp.edit().remove(key).apply());
            d.setPositiveButton("Close", null).show();
        } catch (Exception e) { }
    }

    void download(String url, String ua, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
        r.setMimeType(mime);
        r.addRequestHeader("User-Agent", ua);
        String ck = CookieManager.getInstance().getCookie(url);
        if (ck != null) r.addRequestHeader("Cookie", ck);
        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
        long id = ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
        try {
            JSONArray a = new JSONArray(sp.getString("dl", "[]"));
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("t", name); o.put("m", mime);
            JSONArray n = new JSONArray();
            n.put(o);
            for (int i = 0; i < a.length(); i++) n.put(a.get(i));
            sp.edit().putString("dl", n.toString()).apply();
        } catch (Exception e) { }
        Toast.makeText(this, "Downloading " + name, Toast.LENGTH_SHORT).show();
    }

    void showDownloads() {
        try {
            final JSONArray a = new JSONArray(sp.getString("dl", "[]"));
            final DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            String[] names = new String[a.length()];
            for (int i = 0; i < names.length; i++) {
                JSONObject o = a.getJSONObject(i);
                String st = "Unknown";
                Cursor c = dm.query(new DownloadManager.Query().setFilterById(o.getLong("id")));
                if (c != null) {
                    if (c.moveToFirst()) {
                        int s = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        long tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                        long got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_SO_FAR));
                        st = s == 8 ? "Completed" : s == 16 ? "Failed" : s == 4 ? "Paused"
                            : s == 1 ? "Waiting" : "Downloading " + (tot > 0 ? (got * 100 / tot) + "%" : "");
                    }
                    c.close();
                }
                names[i] = o.getString("t") + "\n" + st;
            }
            AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle("Downloads");
            if (names.length == 0) d.setMessage("No downloads yet.");
            else d.setItems(names, (x, i) -> {
                try {
                    JSONObject o = a.getJSONObject(i);
                    Uri f = dm.getUriForDownloadedFile(o.getLong("id"));
                    if (f == null) { Toast.makeText(this, "File not ready", Toast.LENGTH_SHORT).show(); return; }
                    startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(f, o.getString("m"))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                } catch (Exception e) { Toast.makeText(this, "No app to open this file", Toast.LENGTH_SHORT).show(); }
            });
            d.setNeutralButton("Clear list", (x, i) -> sp.edit().remove("dl").apply());
            d.setPositiveButton("Close", null).show();
        } catch (Exception e) { }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
