VGP Browser - Android project
1. Install Android Studio (developer.android.com/studio)
2. File > Open > select the VGPBrowser folder, wait for Gradle sync
3. Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
4. No phone? Tools > Device Manager > create a virtual device > press Run
